﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using WebApplication44.Data;
using WebApplication44.Models;

namespace WebApplication44.Pages.Shop
{
    public class CreateModel : PageModel
    {
        private readonly WebApplication44.Data.WebApplication44Context _context;

        public CreateModel(WebApplication44.Data.WebApplication44Context context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
        ViewData["CategoryId"] = new SelectList(_context.Set<CategoryModel>(), "Id", "Id");
        ViewData["VendorId"] = new SelectList(_context.Set<VendorModel>(), "Id", "Id");
            return Page();
        }

        [BindProperty]
        public ProductModel ProductModel { get; set; } = default!;

        // For more information, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.ProductModel.Add(ProductModel);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}
