﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WebApplication44.Data;
using WebApplication44.Models;

namespace WebApplication44.Pages.Shop
{
    public class IndexModel : PageModel
    {
        private readonly WebApplication44.Data.WebApplication44Context _context;

        public IndexModel(WebApplication44.Data.WebApplication44Context context)
        {
            _context = context;
        }

        public IList<ProductModel> ProductModel { get;set; } = default!;

        public async Task OnGetAsync()
        {
            ProductModel = await _context.ProductModel
                .Include(p => p.Category)
                .Include(p => p.Vendor).ToListAsync();
        }
    }
}
