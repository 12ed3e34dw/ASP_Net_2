﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using WebApplication44.Models;

namespace WebApplication44.Data
{
    public class WebApplication44Context : DbContext
    {
        public WebApplication44Context (DbContextOptions<WebApplication44Context> options)
            : base(options)
        {
        }

        public DbSet<WebApplication44.Models.ProductModel> ProductModel { get; set; } = default!;
    }
}
